import { ShieldCheck, Microscope, Factory } from 'lucide-react'

const commitments = [
  {
    icon: Factory,
    title: 'Built for certified manufacturing',
    body: 'Our production process is being developed to ISO 13485 standards from day one, not bolted on after the fact.',
  },
  {
    icon: Microscope,
    title: 'Doctor-directed treatment plans',
    body: 'Every case is reviewed and directed by a licensed dental professional before your aligners are produced.',
  },
  {
    icon: ShieldCheck,
    title: 'Transparent, no-surprise pricing',
    body: 'One clear price for your plan, quoted up front, with no hidden add-ons once treatment begins.',
  },
]

export function Testimonials() {
  return (
    <section id="reviews" className="scroll-mt-20 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-primary">Our commitment</span>
          <h2 className="mt-3 text-balance font-serif text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Built on standards, not just promises
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            ClearPro Aligner is a new brand. Rather than borrow reviews we haven't earned yet,
            here's what we're building toward for every patient.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {commitments.map((c) => (
            <div
              key={c.title}
              className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <c.icon className="h-5 w-5" />
              </span>
              <h3 className="font-serif text-lg font-semibold text-foreground">{c.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{c.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
