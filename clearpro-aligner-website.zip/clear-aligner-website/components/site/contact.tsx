'use client'

import { useState, type FormEvent } from 'react'
import { CheckCircle2, Mail, Phone, MapPin } from 'lucide-react'

export function Contact() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contact" className="scroll-mt-20 py-20">
      <div className="mx-auto grid max-w-6xl gap-12 px-4 lg:grid-cols-2">
        <div className="flex flex-col gap-6">
          <span className="text-sm font-semibold uppercase tracking-widest text-primary">
            Book a free consultation
          </span>
          <h2 className="text-balance font-serif text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Ready to start your smile journey?
          </h2>
          <p className="text-pretty text-lg leading-relaxed text-muted-foreground">
            Tell us a bit about yourself and a smile advisor will reach out to help you choose the
            right plan and get your impression kit on the way.
          </p>

          <div className="mt-2 flex flex-col gap-4">
            <div className="flex items-center gap-3 text-foreground">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Mail className="h-5 w-5" />
              </span>
              hello@alinea.com
            </div>
            <div className="flex items-center gap-3 text-foreground">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Phone className="h-5 w-5" />
              </span>
              1-800-SMILE-NOW
            </div>
            <div className="flex items-center gap-3 text-foreground">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <MapPin className="h-5 w-5" />
              </span>
              Nationwide remote treatment
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-8 shadow-lg">
          {submitted ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 py-12 text-center">
              <CheckCircle2 className="h-14 w-14 text-primary" />
              <h3 className="font-serif text-2xl font-bold text-foreground">You&apos;re all set!</h3>
              <p className="text-pretty leading-relaxed text-muted-foreground">
                Thanks for reaching out. A smile advisor will contact you within one business day to
                get your journey started.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="First name" id="firstName">
                  <input
                    id="firstName"
                    name="firstName"
                    required
                    className="input-base"
                    placeholder="Jamie"
                  />
                </Field>
                <Field label="Last name" id="lastName">
                  <input
                    id="lastName"
                    name="lastName"
                    required
                    className="input-base"
                    placeholder="Rivera"
                  />
                </Field>
              </div>
              <Field label="Email" id="email">
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="input-base"
                  placeholder="jamie@example.com"
                />
              </Field>
              <Field label="Phone" id="phone">
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  className="input-base"
                  placeholder="(555) 123-4567"
                />
              </Field>
              <Field label="Which plan interests you?" id="plan">
                <select id="plan" name="plan" className="input-base" defaultValue="">
                  <option value="" disabled>
                    Select a plan
                  </option>
                  <option>Impression Kit</option>
                  <option>Single Pay</option>
                  <option>SmilePay (monthly)</option>
                  <option>Not sure yet</option>
                </select>
              </Field>
              <Field label="Anything else?" id="message">
                <textarea
                  id="message"
                  name="message"
                  rows={3}
                  className="input-base resize-none"
                  placeholder="Tell us about your smile goals"
                />
              </Field>
              <button
                type="submit"
                className="mt-2 rounded-md bg-primary px-6 py-3.5 text-base font-semibold uppercase tracking-wide text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Book my consultation
              </button>
              <p className="text-center text-xs text-muted-foreground">
                By submitting, you agree to be contacted about ClearPro Aligner treatment options.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}

function Field({
  label,
  id,
  children,
}: {
  label: string
  id: string
  children: React.ReactNode
}) {
  return (
    <label htmlFor={id} className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-foreground">{label}</span>
      {children}
    </label>
  )
}
