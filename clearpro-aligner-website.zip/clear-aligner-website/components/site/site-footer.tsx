import Link from 'next/link'
import Image from 'next/image'

const columns = [
  {
    title: 'Treatment',
    links: [
      { label: 'How it works', href: '#how-it-works' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Impression kit', href: '#pricing' },
      { label: 'Retainers', href: '#pricing' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'Our standards', href: '#reviews' },
      { label: 'FAQ', href: '#faq' },
      { label: 'Our doctors', href: '#how-it-works' },
      { label: 'Contact', href: '#contact' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Help center', href: '#faq' },
      { label: 'Book consultation', href: '#contact' },
      { label: 'Track my order', href: '#contact' },
      { label: 'Log in', href: '#contact' },
    ],
  },
]

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-4">
        <div className="flex flex-col gap-4">
          <Link href="/" className="flex items-center gap-2.5">
            <Image
              src="/images/clearpro-mark.png"
              alt=""
              width={46}
              height={15}
              className="h-4 w-auto"
            />
            <span className="font-serif text-lg font-semibold tracking-tight text-foreground">
              ClearPro <span className="font-medium text-muted-foreground">Aligner</span>
            </span>
          </Link>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Doctor-directed clear aligners, manufactured to ISO 13485 standards. A confident smile, made simple.
          </p>
        </div>

        {columns.map((col) => (
          <div key={col.title} className="flex flex-col gap-3">
            <h3 className="font-serif text-sm font-semibold text-foreground">{col.title}</h3>
            <ul className="flex flex-col gap-2">
              {col.links.map((l) => (
                <li key={l.label}>
                  <Link
                    href={l.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-sm text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} ClearPro Aligner. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#" className="transition-colors hover:text-primary">
              Privacy
            </Link>
            <Link href="#" className="transition-colors hover:text-primary">
              Terms
            </Link>
            <Link href="#" className="transition-colors hover:text-primary">
              Accessibility
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
