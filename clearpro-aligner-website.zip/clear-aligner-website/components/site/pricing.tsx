import Link from 'next/link'
import { Check } from 'lucide-react'

const plans = [
  {
    name: 'Impression Kit',
    price: '$49',
    cadence: 'one-time',
    desc: 'Start risk-free. Credited back when you begin treatment.',
    features: [
      'At-home impression kit',
      'Prepaid return shipping',
      'Doctor smile assessment',
      '3D preview of your results',
    ],
    cta: 'Order my kit',
    featured: false,
  },
  {
    name: 'Single Pay',
    price: '$1,899',
    cadence: 'one-time',
    desc: 'The full treatment, paid upfront for the best value.',
    features: [
      'Complete set of clear aligners',
      'Doctor-directed treatment plan',
      'Remote progress monitoring',
      'Free shipping both ways',
      'One set of finishing retainers',
    ],
    cta: 'Choose Single Pay',
    featured: true,
  },
  {
    name: 'SmilePay',
    price: '$89',
    cadence: 'per month',
    desc: 'Flexible monthly plan with no credit check required.',
    features: [
      'Complete set of clear aligners',
      'Doctor-directed treatment plan',
      'Remote progress monitoring',
      'Low $250 down payment',
      '0% financing available',
    ],
    cta: 'Choose SmilePay',
    featured: false,
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="scroll-mt-20 bg-secondary/40 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-primary">Pricing</span>
          <h2 className="mt-3 text-balance font-serif text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Transparent pricing, no surprises
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Up to 60% less than traditional braces or in-office aligners. Choose the plan that fits
            your budget.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col rounded-2xl border p-8 ${
                plan.featured
                  ? 'border-primary bg-card shadow-xl ring-1 ring-primary'
                  : 'border-border bg-card'
              }`}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-1 text-xs font-semibold text-primary-foreground">
                  Most popular
                </span>
              )}
              <h3 className="font-serif text-xl font-semibold text-foreground">{plan.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-serif text-4xl font-bold text-foreground">{plan.price}</span>
                <span className="text-sm text-muted-foreground">/ {plan.cadence}</span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{plan.desc}</p>
              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-foreground">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="#contact"
                className={`mt-8 rounded-full px-6 py-3 text-center text-sm font-semibold transition-transform hover:scale-105 ${
                  plan.featured
                    ? 'bg-primary text-primary-foreground'
                    : 'border border-border bg-background text-foreground hover:bg-secondary'
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
