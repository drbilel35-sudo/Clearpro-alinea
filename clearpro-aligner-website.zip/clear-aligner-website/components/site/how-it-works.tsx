import Image from 'next/image'
import { PackageOpen, ScanLine, Boxes, Smile } from 'lucide-react'

const steps = [
  {
    icon: PackageOpen,
    title: 'Order your impression kit',
    desc: 'We ship an at-home kit so you can take dental impressions in about 30 minutes — no clinic visit required.',
  },
  {
    icon: ScanLine,
    title: 'A doctor reviews your smile',
    desc: 'A licensed dentist or orthodontist maps out your custom treatment plan and 3D preview of your new smile.',
  },
  {
    icon: Boxes,
    title: 'Aligners arrive at your door',
    desc: 'Your full set of clear aligners is manufactured and delivered, with each set worn for about two weeks.',
  },
  {
    icon: Smile,
    title: 'Reveal your new smile',
    desc: 'Track progress with remote check-ins from your care team, then keep it perfect with a set of retainers.',
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="scroll-mt-20 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-primary">
            How it works
          </span>
          <h2 className="mt-3 text-balance font-serif text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Your smile journey in four simple steps
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            No dental chairs, no monthly office visits. Everything happens from home, guided by real
            doctors.
          </p>
        </div>

        <div className="mt-14 grid items-center gap-12 lg:grid-cols-2">
          <div className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-lg">
            <Image
              src="/images/impression-kit.png"
              alt="ClearPro at-home dental impression kit laid out neatly"
              width={720}
              height={620}
              className="h-full w-full object-cover"
            />
          </div>

          <ol className="flex flex-col gap-6">
            {steps.map((step, i) => (
              <li key={step.title} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <step.icon className="h-6 w-6" />
                  </span>
                  {i < steps.length - 1 && <span className="mt-2 h-full w-px flex-1 bg-border" aria-hidden="true" />}
                </div>
                <div className="pb-2">
                  <h3 className="font-serif text-lg font-semibold text-foreground">
                    {i + 1}. {step.title}
                  </h3>
                  <p className="mt-1 leading-relaxed text-muted-foreground">{step.desc}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
