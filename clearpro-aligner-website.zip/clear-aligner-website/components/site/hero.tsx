import Image from 'next/image'
import Link from 'next/link'
import { Star, ShieldCheck, Truck } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
        <div className="flex flex-col items-start gap-6">
          <span className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.2em] text-accent">
            <Star className="h-3.5 w-3.5 fill-current" />
            ISO 13485 manufacturing standard
          </span>
          <h1 className="text-balance font-serif text-5xl font-medium leading-[1.05] tracking-tight text-foreground md:text-7xl">
            A straighter smile, from the comfort of home
          </h1>
          <p className="max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            ClearPro clear aligners are doctor-directed, virtually invisible, and delivered to
            your door — for less than traditional braces.
          </p>
          <div className="mt-2 flex flex-col gap-3 sm:flex-row">
            <Link
              href="#pricing"
              className="rounded-md bg-primary px-7 py-3.5 text-center text-sm font-semibold uppercase tracking-wide text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Start my smile plan
            </Link>
            <Link
              href="#how-it-works"
              className="rounded-md border border-foreground/20 px-7 py-3.5 text-center text-sm font-semibold uppercase tracking-wide text-foreground transition-colors hover:bg-secondary"
            >
              See how it works
            </Link>
          </div>
          <div className="mt-2 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Doctor-directed care
            </span>
            <span className="inline-flex items-center gap-2">
              <Truck className="h-4 w-4 text-primary" />
              Free shipping
            </span>
          </div>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-lg border border-border bg-card">
            <Image
              src="/images/hero-smile.png"
              alt="Person holding a clear aligner and smiling confidently"
              width={720}
              height={720}
              priority
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="border-y border-border/60 bg-secondary/40">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-8 text-center md:grid-cols-4">
          {[
            { stat: 'ISO 13485', label: 'Certified manufacturing' },
            { stat: 'Up to 60%', label: 'Less than braces' },
            { stat: '4–6 mo', label: 'Average treatment' },
            { stat: '100%', label: 'Remote monitoring' },
          ].map((item) => (
            <div key={item.label} className="flex flex-col gap-1">
              <span className="font-serif text-2xl font-bold text-primary md:text-3xl">{item.stat}</span>
              <span className="text-sm text-muted-foreground">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
