'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const faqs = [
  {
    q: 'Are clear aligners as effective as braces?',
    a: 'For most mild to moderate cases of crowding and spacing, clear aligners deliver results comparable to braces. During your assessment, a licensed doctor confirms whether you are a good candidate before any treatment begins.',
  },
  {
    q: 'Do I ever need to visit a dentist in person?',
    a: 'No. The entire process is remote. You take impressions at home with our kit, and your treatment is directed and monitored by a licensed dentist or orthodontist through our platform.',
  },
  {
    q: 'How long does treatment take?',
    a: 'Most people complete treatment in 4 to 6 months, though it varies based on your individual plan. Your doctor gives you an estimated timeline with your custom smile plan.',
  },
  {
    q: 'How much do the aligners cost?',
    a: 'Treatment is $1,899 as a one-time payment, or $89/month with SmilePay financing and a $250 down payment. That is up to 60% less than traditional braces or in-office aligners.',
  },
  {
    q: 'What if I am not a good candidate?',
    a: 'If our doctors determine that clear aligners are not right for you after reviewing your impressions, we will let you know and refund your impression kit — no treatment charges apply.',
  },
  {
    q: 'How many hours a day do I wear them?',
    a: 'For best results, wear your aligners 20 to 22 hours per day, removing them only to eat, drink anything other than water, and brush your teeth.',
  },
]

export function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section id="faq" className="scroll-mt-20 bg-secondary/40 py-20">
      <div className="mx-auto max-w-3xl px-4">
        <div className="text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-primary">FAQ</span>
          <h2 className="mt-3 text-balance font-serif text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Questions? We have answers
          </h2>
        </div>

        <div className="mt-10 flex flex-col gap-3">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i
            return (
              <div key={faq.q} className="overflow-hidden rounded-xl border border-border bg-card">
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-serif text-base font-semibold text-foreground">{faq.q}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-primary transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 leading-relaxed text-muted-foreground">{faq.a}</div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
